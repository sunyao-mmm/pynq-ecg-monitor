# Static Capture Diagnostic

`pynq_ecg.py` is retained only for engineering diagnosis.

Use it to:

- Compare ordinary capture-and-stop mode with the continuous ring.
- Verify the ADS1292/RTL chain when the web page fails.
- Generate a fixed 2000-sample reference.

It is not a second product interface and is not part of the main demonstration flow.
