# Rebuild and run the final ecg_core testbench from the extracted project.
#
# Usage: from the extracted project root, run this file from the Vivado Tcl
# console after closing any project that is already open.

set script_dir [file dirname [file normalize [info script]]]
set project_root [file normalize [file join $script_dir ..]]
set project_file [file join $project_root project_1 project_1.xpr]

if {![file exists $project_file]} {
    error "Project file not found: $project_file"
}

open_project $project_file
set_property top tb_ecg_core [get_filesets sim_1]
set_property top_lib xil_defaultlib [get_filesets sim_1]
reset_run sim_1
launch_simulation
run all
close_sim

puts "FINAL_SIM_RUN_COMPLETE: verify RESULT: PASS in the XSim transcript"
