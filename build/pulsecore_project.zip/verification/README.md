# Verification Evidence

This directory distinguishes final evidence from retired diagnostics.

## Final reports

- `timing_final.rpt` is the authoritative post-route physical-optimization
  timing report: WNS +0.036 ns, WHS +0.039 ns, zero failing endpoints.
- `util_final.rpt` is the final placed-resource report.
- `impl_run.log` is the final implementation log.

The `ecg_bd_wrapper_timing_summary_routed.rpt` file inside the Vivado run is an
intermediate pre-physical-optimization report (WNS -0.144 ns). It is retained
only because Vivado generated it and must not be cited as final evidence.

## RTL simulation status

The active testbench is:

`../project_1/project_1.srcs/sim_1/imports/xu/phase2_axil/tb_ecg_core.v`

The cached XSim output dated 2026-09-26 predates the final `clt_qrs.v` and
`ecg_core.v`. It has therefore been moved to `legacy/simulation_2026-09-26`
instead of being presented as a final-version pass result. A fresh Vivado/XSim
run must be performed before quoting that specific testbench as final evidence.
From the Vivado Tcl console, run:

```tcl
source verification/run_final_simulation.tcl
```

That script recompiles and runs `tb_ecg_core` from the current project sources.

The continuous-ring and RAM-wrap testbench sources are:

- `tb_ecg_continuous.v`
- `tb_ring_memory.v`

## ROM data

The active Block Memory Generator points to:

`../project_1/project_1.srcs/sources_1/imports/xu/phase2_axil/rom/ecg_rom_208.coe`

The obsolete `ecg_rom.coe` was removed from the active Vivado source list and
moved to `legacy/` so it cannot be mistaken for the configured ROM.

## Diagnostics

`pynq_ecg.py` and `STATIC_CAPTURE_DIAGNOSTIC.md` describe the ordinary,
capture-and-stop workflow. They are engineering diagnostics, not the main
product interface.
