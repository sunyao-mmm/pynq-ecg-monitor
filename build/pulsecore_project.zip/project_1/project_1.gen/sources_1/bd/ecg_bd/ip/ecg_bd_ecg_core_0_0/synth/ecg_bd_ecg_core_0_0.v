// (c) Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// (c) Copyright 2022-2026 Advanced Micro Devices, Inc. All rights reserved.
// 
// This file contains confidential and proprietary information
// of AMD and is protected under U.S. and international copyright
// and other intellectual property laws.
// 
// DISCLAIMER
// This disclaimer is not a license and does not grant any
// rights to the materials distributed herewith. Except as
// otherwise provided in a valid license issued to you by
// AMD, and to the maximum extent permitted by applicable
// law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
// WITH ALL FAULTS, AND AMD HEREBY DISCLAIMS ALL WARRANTIES
// AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
// BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
// INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
// (2) AMD shall not be liable (whether in contract or tort,
// including negligence, or under any other theory of
// liability) for any loss or damage of any kind or nature
// related to, arising under or in connection with these
// materials, including for any direct, or any indirect,
// special, incidental, or consequential loss or damage
// (including loss of data, profits, goodwill, or any type of
// loss or damage suffered as a result of any action brought
// by a third party) even if such damage or loss was
// reasonably foreseeable or AMD had been advised of the
// possibility of the same.
// 
// CRITICAL APPLICATIONS
// AMD products are not designed or intended to be fail-
// safe, or for use in any application requiring fail-safe
// performance, such as life-support or safety devices or
// systems, Class III medical devices, nuclear facilities,
// applications related to the deployment of airbags, or any
// other applications that could lead to death, personal
// injury, or severe property or environmental damage
// (individually and collectively, "Critical
// Applications"). Customer assumes the sole risk and
// liability of any use of AMD products in Critical
// Applications, subject only to applicable laws and
// regulations governing limitations on product liability.
// 
// THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
// PART OF THIS FILE AT ALL TIMES.
// 
// DO NOT MODIFY THIS FILE.


// IP VLNV: xilinx.com:module_ref:ecg_core:1.0
// IP Revision: 1

(* X_CORE_INFO = "ecg_core,Vivado 2024.2" *)
(* CHECK_LICENSE_TYPE = "ecg_bd_ecg_core_0_0,ecg_core,{}" *)
(* CORE_GENERATION_INFO = "ecg_bd_ecg_core_0_0,ecg_core,{x_ipProduct=Vivado 2024.2,x_ipVendor=xilinx.com,x_ipLibrary=module_ref,x_ipName=ecg_core,x_ipVersion=1.0,x_ipCoreRevision=1,x_ipLanguage=VERILOG,x_ipSimLanguage=MIXED,CLK_PER_SAMPLE=80000,ROM_LEN=711,ROM_AW=10,CAP_AW=12,ROM_SETTLE=4,SETTLE=96,CAL_FIRST=1}" *)
(* IP_DEFINITION_SOURCE = "module_ref" *)
(* DowngradeIPIdentifiedWarnings = "yes" *)
module ecg_bd_ecg_core_0_0 (
  clk,
  rst_n,
  run,
  soft_rst,
  cap_len_in,
  src_sel,
  adc_sample,
  adc_valid,
  rom_addr,
  rom_data,
  cap_we,
  cap_addr,
  cap_data,
  st_clt_now,
  st_r_index,
  st_r_amp,
  st_bpm,
  st_rr_samples,
  st_beat_count,
  st_rr_bad_cnt,
  st_cap_done
);

(* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 clk CLK" *)
(* X_INTERFACE_MODE = "slave" *)
(* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME clk, ASSOCIATED_RESET rst_n, FREQ_HZ 20000000, PHASE 0.0, FREQ_TOLERANCE_HZ 0, CLK_DOMAIN ecg_bd_processing_system7_0_0_FCLK_CLK0, INSERT_VIP 0" *)
input wire clk;
(* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 rst_n RST" *)
(* X_INTERFACE_MODE = "slave" *)
(* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME rst_n, POLARITY ACTIVE_LOW, INSERT_VIP 0" *)
input wire rst_n;
input wire run;
(* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 soft_rst RST" *)
(* X_INTERFACE_MODE = "slave" *)
(* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME soft_rst, POLARITY ACTIVE_LOW, INSERT_VIP 0" *)
input wire soft_rst;
input wire [31 : 0] cap_len_in;
input wire src_sel;
input wire [15 : 0] adc_sample;
input wire adc_valid;
output wire [9 : 0] rom_addr;
input wire [15 : 0] rom_data;
output wire cap_we;
output wire [11 : 0] cap_addr;
output wire [31 : 0] cap_data;
output wire [31 : 0] st_clt_now;
output wire [31 : 0] st_r_index;
output wire [15 : 0] st_r_amp;
output wire [15 : 0] st_bpm;
output wire [31 : 0] st_rr_samples;
output wire [31 : 0] st_beat_count;
output wire [31 : 0] st_rr_bad_cnt;
output wire st_cap_done;

  ecg_core #(
    .CLK_PER_SAMPLE(80000),
    .ROM_LEN(711),
    .ROM_AW(10),
    .CAP_AW(12),
    .ROM_SETTLE(4),
    .SETTLE(96),
    .CAL_FIRST(1)
  ) inst (
    .clk(clk),
    .rst_n(rst_n),
    .run(run),
    .soft_rst(soft_rst),
    .cap_len_in(cap_len_in),
    .src_sel(src_sel),
    .adc_sample(adc_sample),
    .adc_valid(adc_valid),
    .rom_addr(rom_addr),
    .rom_data(rom_data),
    .cap_we(cap_we),
    .cap_addr(cap_addr),
    .cap_data(cap_data),
    .st_clt_now(st_clt_now),
    .st_r_index(st_r_index),
    .st_r_amp(st_r_amp),
    .st_bpm(st_bpm),
    .st_rr_samples(st_rr_samples),
    .st_beat_count(st_beat_count),
    .st_rr_bad_cnt(st_rr_bad_cnt),
    .st_cap_done(st_cap_done)
  );
endmodule
