# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  ipgui::add_param $IPINST -name "CLK_HZ" -parent ${Page_0}
  ipgui::add_param $IPINST -name "DIAG_BATCHES" -parent ${Page_0}
  ipgui::add_param $IPINST -name "DIAG_GAP" -parent ${Page_0}
  ipgui::add_param $IPINST -name "DIAG_SPACE" -parent ${Page_0}
  ipgui::add_param $IPINST -name "DIAG_WARM" -parent ${Page_0}
  ipgui::add_param $IPINST -name "GAP_CYC" -parent ${Page_0}
  ipgui::add_param $IPINST -name "RESET_WAIT" -parent ${Page_0}
  ipgui::add_param $IPINST -name "SCLK_HZ" -parent ${Page_0}


}

proc update_PARAM_VALUE.CLK_HZ { PARAM_VALUE.CLK_HZ } {
	# Procedure called to update CLK_HZ when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.CLK_HZ { PARAM_VALUE.CLK_HZ } {
	# Procedure called to validate CLK_HZ
	return true
}

proc update_PARAM_VALUE.DIAG_BATCHES { PARAM_VALUE.DIAG_BATCHES } {
	# Procedure called to update DIAG_BATCHES when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.DIAG_BATCHES { PARAM_VALUE.DIAG_BATCHES } {
	# Procedure called to validate DIAG_BATCHES
	return true
}

proc update_PARAM_VALUE.DIAG_GAP { PARAM_VALUE.DIAG_GAP } {
	# Procedure called to update DIAG_GAP when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.DIAG_GAP { PARAM_VALUE.DIAG_GAP } {
	# Procedure called to validate DIAG_GAP
	return true
}

proc update_PARAM_VALUE.DIAG_SPACE { PARAM_VALUE.DIAG_SPACE } {
	# Procedure called to update DIAG_SPACE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.DIAG_SPACE { PARAM_VALUE.DIAG_SPACE } {
	# Procedure called to validate DIAG_SPACE
	return true
}

proc update_PARAM_VALUE.DIAG_WARM { PARAM_VALUE.DIAG_WARM } {
	# Procedure called to update DIAG_WARM when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.DIAG_WARM { PARAM_VALUE.DIAG_WARM } {
	# Procedure called to validate DIAG_WARM
	return true
}

proc update_PARAM_VALUE.GAP_CYC { PARAM_VALUE.GAP_CYC } {
	# Procedure called to update GAP_CYC when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.GAP_CYC { PARAM_VALUE.GAP_CYC } {
	# Procedure called to validate GAP_CYC
	return true
}

proc update_PARAM_VALUE.RESET_WAIT { PARAM_VALUE.RESET_WAIT } {
	# Procedure called to update RESET_WAIT when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.RESET_WAIT { PARAM_VALUE.RESET_WAIT } {
	# Procedure called to validate RESET_WAIT
	return true
}

proc update_PARAM_VALUE.SCLK_HZ { PARAM_VALUE.SCLK_HZ } {
	# Procedure called to update SCLK_HZ when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.SCLK_HZ { PARAM_VALUE.SCLK_HZ } {
	# Procedure called to validate SCLK_HZ
	return true
}


proc update_MODELPARAM_VALUE.CLK_HZ { MODELPARAM_VALUE.CLK_HZ PARAM_VALUE.CLK_HZ } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.CLK_HZ}] ${MODELPARAM_VALUE.CLK_HZ}
}

proc update_MODELPARAM_VALUE.SCLK_HZ { MODELPARAM_VALUE.SCLK_HZ PARAM_VALUE.SCLK_HZ } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.SCLK_HZ}] ${MODELPARAM_VALUE.SCLK_HZ}
}

proc update_MODELPARAM_VALUE.RESET_WAIT { MODELPARAM_VALUE.RESET_WAIT PARAM_VALUE.RESET_WAIT } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.RESET_WAIT}] ${MODELPARAM_VALUE.RESET_WAIT}
}

proc update_MODELPARAM_VALUE.GAP_CYC { MODELPARAM_VALUE.GAP_CYC PARAM_VALUE.GAP_CYC } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.GAP_CYC}] ${MODELPARAM_VALUE.GAP_CYC}
}

proc update_MODELPARAM_VALUE.DIAG_BATCHES { MODELPARAM_VALUE.DIAG_BATCHES PARAM_VALUE.DIAG_BATCHES } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.DIAG_BATCHES}] ${MODELPARAM_VALUE.DIAG_BATCHES}
}

proc update_MODELPARAM_VALUE.DIAG_GAP { MODELPARAM_VALUE.DIAG_GAP PARAM_VALUE.DIAG_GAP } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.DIAG_GAP}] ${MODELPARAM_VALUE.DIAG_GAP}
}

proc update_MODELPARAM_VALUE.DIAG_WARM { MODELPARAM_VALUE.DIAG_WARM PARAM_VALUE.DIAG_WARM } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.DIAG_WARM}] ${MODELPARAM_VALUE.DIAG_WARM}
}

proc update_MODELPARAM_VALUE.DIAG_SPACE { MODELPARAM_VALUE.DIAG_SPACE PARAM_VALUE.DIAG_SPACE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.DIAG_SPACE}] ${MODELPARAM_VALUE.DIAG_SPACE}
}

