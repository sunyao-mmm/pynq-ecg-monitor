# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  ipgui::add_param $IPINST -name "CAL_FIRST" -parent ${Page_0}
  ipgui::add_param $IPINST -name "CAP_AW" -parent ${Page_0}
  ipgui::add_param $IPINST -name "CLK_PER_SAMPLE" -parent ${Page_0}
  ipgui::add_param $IPINST -name "ROM_AW" -parent ${Page_0}
  ipgui::add_param $IPINST -name "ROM_LEN" -parent ${Page_0}
  ipgui::add_param $IPINST -name "ROM_SETTLE" -parent ${Page_0}
  ipgui::add_param $IPINST -name "SETTLE" -parent ${Page_0}


}

proc update_PARAM_VALUE.CAL_FIRST { PARAM_VALUE.CAL_FIRST } {
	# Procedure called to update CAL_FIRST when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.CAL_FIRST { PARAM_VALUE.CAL_FIRST } {
	# Procedure called to validate CAL_FIRST
	return true
}

proc update_PARAM_VALUE.CAP_AW { PARAM_VALUE.CAP_AW } {
	# Procedure called to update CAP_AW when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.CAP_AW { PARAM_VALUE.CAP_AW } {
	# Procedure called to validate CAP_AW
	return true
}

proc update_PARAM_VALUE.CLK_PER_SAMPLE { PARAM_VALUE.CLK_PER_SAMPLE } {
	# Procedure called to update CLK_PER_SAMPLE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.CLK_PER_SAMPLE { PARAM_VALUE.CLK_PER_SAMPLE } {
	# Procedure called to validate CLK_PER_SAMPLE
	return true
}

proc update_PARAM_VALUE.ROM_AW { PARAM_VALUE.ROM_AW } {
	# Procedure called to update ROM_AW when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.ROM_AW { PARAM_VALUE.ROM_AW } {
	# Procedure called to validate ROM_AW
	return true
}

proc update_PARAM_VALUE.ROM_LEN { PARAM_VALUE.ROM_LEN } {
	# Procedure called to update ROM_LEN when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.ROM_LEN { PARAM_VALUE.ROM_LEN } {
	# Procedure called to validate ROM_LEN
	return true
}

proc update_PARAM_VALUE.ROM_SETTLE { PARAM_VALUE.ROM_SETTLE } {
	# Procedure called to update ROM_SETTLE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.ROM_SETTLE { PARAM_VALUE.ROM_SETTLE } {
	# Procedure called to validate ROM_SETTLE
	return true
}

proc update_PARAM_VALUE.SETTLE { PARAM_VALUE.SETTLE } {
	# Procedure called to update SETTLE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.SETTLE { PARAM_VALUE.SETTLE } {
	# Procedure called to validate SETTLE
	return true
}


proc update_MODELPARAM_VALUE.CLK_PER_SAMPLE { MODELPARAM_VALUE.CLK_PER_SAMPLE PARAM_VALUE.CLK_PER_SAMPLE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.CLK_PER_SAMPLE}] ${MODELPARAM_VALUE.CLK_PER_SAMPLE}
}

proc update_MODELPARAM_VALUE.ROM_LEN { MODELPARAM_VALUE.ROM_LEN PARAM_VALUE.ROM_LEN } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.ROM_LEN}] ${MODELPARAM_VALUE.ROM_LEN}
}

proc update_MODELPARAM_VALUE.ROM_AW { MODELPARAM_VALUE.ROM_AW PARAM_VALUE.ROM_AW } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.ROM_AW}] ${MODELPARAM_VALUE.ROM_AW}
}

proc update_MODELPARAM_VALUE.CAP_AW { MODELPARAM_VALUE.CAP_AW PARAM_VALUE.CAP_AW } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.CAP_AW}] ${MODELPARAM_VALUE.CAP_AW}
}

proc update_MODELPARAM_VALUE.ROM_SETTLE { MODELPARAM_VALUE.ROM_SETTLE PARAM_VALUE.ROM_SETTLE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.ROM_SETTLE}] ${MODELPARAM_VALUE.ROM_SETTLE}
}

proc update_MODELPARAM_VALUE.SETTLE { MODELPARAM_VALUE.SETTLE PARAM_VALUE.SETTLE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.SETTLE}] ${MODELPARAM_VALUE.SETTLE}
}

proc update_MODELPARAM_VALUE.CAL_FIRST { MODELPARAM_VALUE.CAL_FIRST PARAM_VALUE.CAL_FIRST } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.CAL_FIRST}] ${MODELPARAM_VALUE.CAL_FIRST}
}

