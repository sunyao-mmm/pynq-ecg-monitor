`timescale 1ns / 1ps
`default_nettype none
//==========================================================================
// tb_heart_rate.v -- unit test for heart_rate.v   (HR-3: stimulus on the falling edge)
//   injects R peaks with known RR intervals (in samples) and checks the bpm,
//   including the two window limits and one out-of-window (too short) interval.
//      RR=360 -> 60 bpm      RR=300 -> 72 bpm     RR=240 -> 90 bpm
//      RR=180 -> 120 bpm     RR=720 -> 30 bpm     RR=108 -> 200 bpm
//      RR= 50 -> out of window -> rr_bad, bpm must NOT update
//   ASCII only on purpose.
//==========================================================================
module tb_heart_rate;

    reg clk = 1'b0;
    always #5 clk = ~clk;                     // 100 MHz

    reg         rst_n;
    reg         r_valid;
    reg  [31:0] r_index;
    wire [15:0] bpm;
    wire        bpm_valid;
    wire [31:0] rr_samples, rr_avg;
    wire        rr_bad;
    wire [31:0] beat_count;

    integer i, errs, n_ok, n_bad;
    integer rr_list  [0:6];
    integer exp_bpm  [0:6];
    integer exp_bad  [0:6];
    integer exp_now, bad_now;
    reg [31:0] idx;

    heart_rate #(.FS_HZ(360), .BPM_MIN(30), .BPM_MAX(200)) dut (
        .clk(clk), .rst_n(rst_n), .r_valid(r_valid), .r_index(r_index),
        .bpm(bpm), .bpm_valid(bpm_valid),
        .rr_samples(rr_samples), .rr_avg(rr_avg), .rr_bad(rr_bad), .beat_count(beat_count)
    );

    always @(posedge clk) begin
        if (rst_n && bpm_valid) begin
            $display("  RR=%0d samples -> bpm=%0d  (expect %0d)   rr_avg=%0d",
                     rr_samples, bpm, exp_now, rr_avg);
            if (bpm !== exp_now) errs = errs + 1; else n_ok = n_ok + 1;
        end
        if (rst_n && rr_bad) begin
            n_bad = n_bad + 1;
            $display("  rr_bad pulse                                  (expect %0d)", bad_now);
            if (bad_now !== 1) errs = errs + 1;
        end
    end

    initial begin
        rr_list[0] = 360; exp_bpm[0] =  60; exp_bad[0] = 0;
        rr_list[1] = 300; exp_bpm[1] =  72; exp_bad[1] = 0;
        rr_list[2] = 240; exp_bpm[2] =  90; exp_bad[2] = 0;
        rr_list[3] = 180; exp_bpm[3] = 120; exp_bad[3] = 0;
        rr_list[4] = 720; exp_bpm[4] =  30; exp_bad[4] = 0;
        rr_list[5] = 108; exp_bpm[5] = 200; exp_bad[5] = 0;
        rr_list[6] =  50; exp_bpm[6] =  -1; exp_bad[6] = 1;

        rst_n = 1'b0; r_valid = 1'b0; r_index = 32'd0;
        errs = 0; n_ok = 0; n_bad = 0; exp_now = -1; bad_now = 0; idx = 32'd1000;

        repeat (5) @(negedge clk);
        rst_n = 1'b1;
        repeat (2) @(negedge clk);

        $display("=========== heart_rate unit test ===========");
        $display("*** TB BUILD HR-3 ***");
        // The stimulus is driven on the FALLING edge.  Driving it on the rising edge
        // (as v1/v2 did) races with the DUT sampling on that same edge: one simulator
        // lets the testbench win, another lets the DUT win.  That was the xsim failure.
        // first R peak: no interval yet
        @(negedge clk); r_index = idx; r_valid = 1'b1;
        @(negedge clk); r_valid = 1'b0;
        repeat (40) @(negedge clk);   // let the serial divider finish before the next beat

        for (i = 0; i < 7; i = i + 1) begin
            exp_now = exp_bpm[i];
            bad_now = exp_bad[i];
            idx     = idx + rr_list[i];
            @(negedge clk); r_index = idx; r_valid = 1'b1;
            @(negedge clk); r_valid = 1'b0;
            // the DUT has processed the beat by now (one rising edge in between)
            $display("    [dbg] beat %0d sent: r_index=%0d -> dut.prev_index=%0d  dut.rr_samples=%0d  dut.rr_bad=%0d  dut.beat_count=%0d",
                     i+1, idx, dut.prev_index, dut.rr_samples, dut.rr_bad, dut.beat_count);
            repeat (40) @(negedge clk);   // let the serial divider finish before the next beat
        end
        repeat (40) @(negedge clk);

        $display("-------------------------------------------------");
        $display("checks passed = %0d   errors = %0d   rr_bad pulses = %0d (expect 1)",
                 n_ok, errs, n_bad);
        if (errs == 0 && n_ok == 6 && n_bad == 1) $display("  RESULT: PASS");
        else                                     $display("  RESULT: FAIL");
        $display("=================================================");
        $finish;
    end

endmodule
`default_nettype wire
