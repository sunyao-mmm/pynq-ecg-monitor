# Synchronization Summary

Updated on 2026-10-26.

## Replaced

- `project_1/project_1.srcs/sim_1/imports/xu/phase2_axil/tb_ecg_core.v`
  - Updated to the testbench matching the current RTL.

## Already current

- `project_1/project_1.srcs/sources_1/imports/xu/phase2_axil/ecg_core.v`
- `project_1/project_1.srcs/sources_1/imports/xu/ecg_fpga_files/clt_qrs.v`

## Added

- `deploy/`: timing-qualified bitstream, HWH, web monitor, test helper, and board notes.
- `verification/`: static diagnostic script, continuous-ring/RAM-wrap testbenches,
  final timing/utilization reports, and implementation log.
- `verification/legacy/`: retired pre-final simulation cache and unused COE,
  isolated from the active sources with an explanatory README.

## Deployment cleanup

- Fixed `deploy/run_web.sh` so it runs from the deployment directory rather than
  a nonexistent `web_demo/` subdirectory.
- Distinguished ROM (`0`) and live ADS1292 (`1`) launch modes in the board notes.
- Removed the obsolete `ecg_rom.coe` from the active Vivado source list. The
  configured ROM remains `rom/ecg_rom_208.coe`.
- Identified `timing_final.rpt` as the only authoritative final timing report.
  The pre-physical-optimization routed report is retained as a Vivado run
  artifact but must not be cited as the final result.
- Moved the 2026-09-26 XSim cache out of the active simulation directory because
  it predates the final RTL. No fresh post-final RTL simulation is claimed.

## Result

- WNS: +0.036 ns
- TNS: 0.000 ns
- WHS: +0.039 ns
- THS: 0.000 ns
- Failing endpoints: 0

The bitstream in `deploy/` is the timing-qualified 2026-10-26 22:01 build.
