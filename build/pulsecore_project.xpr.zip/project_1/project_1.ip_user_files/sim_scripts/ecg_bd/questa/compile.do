vlib questa_lib/work
vlib questa_lib/msim

vlib questa_lib/msim/xilinx_vip
vlib questa_lib/msim/xpm
vlib questa_lib/msim/axi_infrastructure_v1_1_0
vlib questa_lib/msim/axi_vip_v1_1_19
vlib questa_lib/msim/processing_system7_vip_v1_0_21
vlib questa_lib/msim/xil_defaultlib
vlib questa_lib/msim/xlconstant_v1_1_9
vlib questa_lib/msim/lib_cdc_v1_0_3
vlib questa_lib/msim/proc_sys_reset_v5_0_16
vlib questa_lib/msim/smartconnect_v1_0
vlib questa_lib/msim/axi_register_slice_v2_1_33
vlib questa_lib/msim/blk_mem_gen_v8_4_9

vmap xilinx_vip questa_lib/msim/xilinx_vip
vmap xpm questa_lib/msim/xpm
vmap axi_infrastructure_v1_1_0 questa_lib/msim/axi_infrastructure_v1_1_0
vmap axi_vip_v1_1_19 questa_lib/msim/axi_vip_v1_1_19
vmap processing_system7_vip_v1_0_21 questa_lib/msim/processing_system7_vip_v1_0_21
vmap xil_defaultlib questa_lib/msim/xil_defaultlib
vmap xlconstant_v1_1_9 questa_lib/msim/xlconstant_v1_1_9
vmap lib_cdc_v1_0_3 questa_lib/msim/lib_cdc_v1_0_3
vmap proc_sys_reset_v5_0_16 questa_lib/msim/proc_sys_reset_v5_0_16
vmap smartconnect_v1_0 questa_lib/msim/smartconnect_v1_0
vmap axi_register_slice_v2_1_33 questa_lib/msim/axi_register_slice_v2_1_33
vmap blk_mem_gen_v8_4_9 questa_lib/msim/blk_mem_gen_v8_4_9

vlog -work xilinx_vip -64 -incr -mfcu  -sv -L axi_vip_v1_1_19 -L smartconnect_v1_0 -L processing_system7_vip_v1_0_21 -L xilinx_vip "+incdir+/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/include" \
"/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/hdl/axi4stream_vip_axi4streampc.sv" \
"/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/hdl/axi_vip_axi4pc.sv" \
"/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/hdl/xil_common_vip_pkg.sv" \
"/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/hdl/axi4stream_vip_pkg.sv" \
"/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/hdl/axi_vip_pkg.sv" \
"/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/hdl/axi4stream_vip_if.sv" \
"/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/hdl/axi_vip_if.sv" \
"/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/hdl/clk_vip_if.sv" \
"/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/hdl/rst_vip_if.sv" \

vlog -work xpm -64 -incr -mfcu  -sv -L axi_vip_v1_1_19 -L smartconnect_v1_0 -L processing_system7_vip_v1_0_21 -L xilinx_vip "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/ec67/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/86fe/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f0b6/hdl/verilog" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0127/hdl/verilog" "+incdir+/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/include" \
"/tools/Xilinx/Vivado/2024.2/data/ip/xpm/xpm_fifo/hdl/xpm_fifo.sv" \
"/tools/Xilinx/Vivado/2024.2/data/ip/xpm/xpm_memory/hdl/xpm_memory.sv" \
"/tools/Xilinx/Vivado/2024.2/data/ip/xpm/xpm_cdc/hdl/xpm_cdc.sv" \

vcom -work xpm -64 -93  \
"/tools/Xilinx/Vivado/2024.2/data/ip/xpm/xpm_VCOMP.vhd" \

vlog -work axi_infrastructure_v1_1_0 -64 -incr -mfcu  "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/ec67/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/86fe/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f0b6/hdl/verilog" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0127/hdl/verilog" "+incdir+/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/include" \
"../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/ec67/hdl/axi_infrastructure_v1_1_vl_rfs.v" \

vlog -work axi_vip_v1_1_19 -64 -incr -mfcu  -sv -L axi_vip_v1_1_19 -L smartconnect_v1_0 -L processing_system7_vip_v1_0_21 -L xilinx_vip "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/ec67/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/86fe/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f0b6/hdl/verilog" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0127/hdl/verilog" "+incdir+/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/include" \
"../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/8c45/hdl/axi_vip_v1_1_vl_rfs.sv" \

vlog -work processing_system7_vip_v1_0_21 -64 -incr -mfcu  -sv -L axi_vip_v1_1_19 -L smartconnect_v1_0 -L processing_system7_vip_v1_0_21 -L xilinx_vip "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/ec67/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/86fe/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f0b6/hdl/verilog" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0127/hdl/verilog" "+incdir+/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/include" \
"../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/86fe/hdl/processing_system7_vip_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib -64 -incr -mfcu  "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/ec67/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/86fe/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f0b6/hdl/verilog" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0127/hdl/verilog" "+incdir+/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/include" \
"../../../bd/ecg_bd/ip/ecg_bd_processing_system7_0_0/sim/ecg_bd_processing_system7_0_0.v" \
"../../../bd/ecg_bd/ip/ecg_bd_ecg_axil_0_0/sim/ecg_bd_ecg_axil_0_0.v" \

vlog -work xlconstant_v1_1_9 -64 -incr -mfcu  "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/ec67/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/86fe/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f0b6/hdl/verilog" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0127/hdl/verilog" "+incdir+/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/include" \
"../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/e2d2/hdl/xlconstant_v1_1_vl_rfs.v" \

vlog -work xil_defaultlib -64 -incr -mfcu  "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/ec67/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/86fe/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f0b6/hdl/verilog" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0127/hdl/verilog" "+incdir+/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/include" \
"../../../bd/ecg_bd/ip/ecg_bd_axi_smc_0/bd_0/ip/ip_0/sim/bd_895d_one_0.v" \

vcom -work lib_cdc_v1_0_3 -64 -93  \
"../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/2a4f/hdl/lib_cdc_v1_0_rfs.vhd" \

vcom -work proc_sys_reset_v5_0_16 -64 -93  \
"../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0831/hdl/proc_sys_reset_v5_0_vh_rfs.vhd" \

vcom -work xil_defaultlib -64 -93  \
"../../../bd/ecg_bd/ip/ecg_bd_axi_smc_0/bd_0/ip/ip_1/sim/bd_895d_psr_aclk_0.vhd" \

vlog -work smartconnect_v1_0 -64 -incr -mfcu  -sv -L axi_vip_v1_1_19 -L smartconnect_v1_0 -L processing_system7_vip_v1_0_21 -L xilinx_vip "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/ec67/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/86fe/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f0b6/hdl/verilog" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0127/hdl/verilog" "+incdir+/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/include" \
"../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f0b6/hdl/sc_util_v1_0_vl_rfs.sv" \
"../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f49a/hdl/sc_mmu_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib -64 -incr -mfcu  -sv -L axi_vip_v1_1_19 -L smartconnect_v1_0 -L processing_system7_vip_v1_0_21 -L xilinx_vip "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/ec67/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/86fe/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f0b6/hdl/verilog" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0127/hdl/verilog" "+incdir+/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/include" \
"../../../bd/ecg_bd/ip/ecg_bd_axi_smc_0/bd_0/ip/ip_2/sim/bd_895d_s00mmu_0.sv" \

vlog -work smartconnect_v1_0 -64 -incr -mfcu  -sv -L axi_vip_v1_1_19 -L smartconnect_v1_0 -L processing_system7_vip_v1_0_21 -L xilinx_vip "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/ec67/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/86fe/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f0b6/hdl/verilog" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0127/hdl/verilog" "+incdir+/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/include" \
"../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/2da8/hdl/sc_transaction_regulator_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib -64 -incr -mfcu  -sv -L axi_vip_v1_1_19 -L smartconnect_v1_0 -L processing_system7_vip_v1_0_21 -L xilinx_vip "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/ec67/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/86fe/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f0b6/hdl/verilog" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0127/hdl/verilog" "+incdir+/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/include" \
"../../../bd/ecg_bd/ip/ecg_bd_axi_smc_0/bd_0/ip/ip_3/sim/bd_895d_s00tr_0.sv" \

vlog -work smartconnect_v1_0 -64 -incr -mfcu  -sv -L axi_vip_v1_1_19 -L smartconnect_v1_0 -L processing_system7_vip_v1_0_21 -L xilinx_vip "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/ec67/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/86fe/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f0b6/hdl/verilog" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0127/hdl/verilog" "+incdir+/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/include" \
"../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/63ed/hdl/sc_si_converter_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib -64 -incr -mfcu  -sv -L axi_vip_v1_1_19 -L smartconnect_v1_0 -L processing_system7_vip_v1_0_21 -L xilinx_vip "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/ec67/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/86fe/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f0b6/hdl/verilog" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0127/hdl/verilog" "+incdir+/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/include" \
"../../../bd/ecg_bd/ip/ecg_bd_axi_smc_0/bd_0/ip/ip_4/sim/bd_895d_s00sic_0.sv" \

vlog -work smartconnect_v1_0 -64 -incr -mfcu  -sv -L axi_vip_v1_1_19 -L smartconnect_v1_0 -L processing_system7_vip_v1_0_21 -L xilinx_vip "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/ec67/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/86fe/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f0b6/hdl/verilog" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0127/hdl/verilog" "+incdir+/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/include" \
"../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/cef3/hdl/sc_axi2sc_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib -64 -incr -mfcu  -sv -L axi_vip_v1_1_19 -L smartconnect_v1_0 -L processing_system7_vip_v1_0_21 -L xilinx_vip "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/ec67/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/86fe/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f0b6/hdl/verilog" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0127/hdl/verilog" "+incdir+/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/include" \
"../../../bd/ecg_bd/ip/ecg_bd_axi_smc_0/bd_0/ip/ip_5/sim/bd_895d_s00a2s_0.sv" \

vlog -work smartconnect_v1_0 -64 -incr -mfcu  -sv -L axi_vip_v1_1_19 -L smartconnect_v1_0 -L processing_system7_vip_v1_0_21 -L xilinx_vip "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/ec67/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/86fe/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f0b6/hdl/verilog" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0127/hdl/verilog" "+incdir+/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/include" \
"../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0127/hdl/sc_node_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib -64 -incr -mfcu  -sv -L axi_vip_v1_1_19 -L smartconnect_v1_0 -L processing_system7_vip_v1_0_21 -L xilinx_vip "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/ec67/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/86fe/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f0b6/hdl/verilog" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0127/hdl/verilog" "+incdir+/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/include" \
"../../../bd/ecg_bd/ip/ecg_bd_axi_smc_0/bd_0/ip/ip_6/sim/bd_895d_sarn_0.sv" \
"../../../bd/ecg_bd/ip/ecg_bd_axi_smc_0/bd_0/ip/ip_7/sim/bd_895d_srn_0.sv" \
"../../../bd/ecg_bd/ip/ecg_bd_axi_smc_0/bd_0/ip/ip_8/sim/bd_895d_sawn_0.sv" \
"../../../bd/ecg_bd/ip/ecg_bd_axi_smc_0/bd_0/ip/ip_9/sim/bd_895d_swn_0.sv" \
"../../../bd/ecg_bd/ip/ecg_bd_axi_smc_0/bd_0/ip/ip_10/sim/bd_895d_sbn_0.sv" \

vlog -work smartconnect_v1_0 -64 -incr -mfcu  -sv -L axi_vip_v1_1_19 -L smartconnect_v1_0 -L processing_system7_vip_v1_0_21 -L xilinx_vip "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/ec67/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/86fe/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f0b6/hdl/verilog" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0127/hdl/verilog" "+incdir+/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/include" \
"../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/7f4f/hdl/sc_sc2axi_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib -64 -incr -mfcu  -sv -L axi_vip_v1_1_19 -L smartconnect_v1_0 -L processing_system7_vip_v1_0_21 -L xilinx_vip "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/ec67/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/86fe/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f0b6/hdl/verilog" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0127/hdl/verilog" "+incdir+/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/include" \
"../../../bd/ecg_bd/ip/ecg_bd_axi_smc_0/bd_0/ip/ip_11/sim/bd_895d_m00s2a_0.sv" \

vlog -work smartconnect_v1_0 -64 -incr -mfcu  -sv -L axi_vip_v1_1_19 -L smartconnect_v1_0 -L processing_system7_vip_v1_0_21 -L xilinx_vip "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/ec67/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/86fe/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f0b6/hdl/verilog" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0127/hdl/verilog" "+incdir+/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/include" \
"../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/37bc/hdl/sc_exit_v1_0_vl_rfs.sv" \

vlog -work xil_defaultlib -64 -incr -mfcu  -sv -L axi_vip_v1_1_19 -L smartconnect_v1_0 -L processing_system7_vip_v1_0_21 -L xilinx_vip "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/ec67/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/86fe/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f0b6/hdl/verilog" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0127/hdl/verilog" "+incdir+/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/include" \
"../../../bd/ecg_bd/ip/ecg_bd_axi_smc_0/bd_0/ip/ip_12/sim/bd_895d_m00e_0.sv" \

vlog -work xil_defaultlib -64 -incr -mfcu  "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/ec67/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/86fe/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f0b6/hdl/verilog" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0127/hdl/verilog" "+incdir+/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/include" \
"../../../bd/ecg_bd/ip/ecg_bd_axi_smc_0/bd_0/sim/bd_895d.v" \

vlog -work smartconnect_v1_0 -64 -incr -mfcu  -sv -L axi_vip_v1_1_19 -L smartconnect_v1_0 -L processing_system7_vip_v1_0_21 -L xilinx_vip "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/ec67/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/86fe/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f0b6/hdl/verilog" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0127/hdl/verilog" "+incdir+/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/include" \
"../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/3718/hdl/sc_switchboard_v1_0_vl_rfs.sv" \

vlog -work axi_register_slice_v2_1_33 -64 -incr -mfcu  "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/ec67/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/86fe/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f0b6/hdl/verilog" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0127/hdl/verilog" "+incdir+/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/include" \
"../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/3ee4/hdl/axi_register_slice_v2_1_vl_rfs.v" \

vlog -work xil_defaultlib -64 -incr -mfcu  "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/ec67/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/86fe/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f0b6/hdl/verilog" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0127/hdl/verilog" "+incdir+/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/include" \
"../../../bd/ecg_bd/ip/ecg_bd_axi_smc_0/sim/ecg_bd_axi_smc_0.v" \

vcom -work xil_defaultlib -64 -93  \
"../../../bd/ecg_bd/ip/ecg_bd_rst_ps7_0_100M_0/sim/ecg_bd_rst_ps7_0_100M_0.vhd" \

vlog -work xil_defaultlib -64 -incr -mfcu  "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/ec67/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/86fe/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f0b6/hdl/verilog" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0127/hdl/verilog" "+incdir+/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/include" \
"../../../bd/ecg_bd/ip/ecg_bd_ecg_core_0_0/sim/ecg_bd_ecg_core_0_0.v" \

vlog -work blk_mem_gen_v8_4_9 -64 -incr -mfcu  "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/ec67/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/86fe/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f0b6/hdl/verilog" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0127/hdl/verilog" "+incdir+/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/include" \
"../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/5ec1/simulation/blk_mem_gen_v8_4.v" \

vlog -work xil_defaultlib -64 -incr -mfcu  "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/ec67/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/86fe/hdl" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/f0b6/hdl/verilog" "+incdir+../../../../project_1.gen/sources_1/bd/ecg_bd/ipshared/0127/hdl/verilog" "+incdir+/tools/Xilinx/Vivado/2024.2/data/xilinx_vip/include" \
"../../../bd/ecg_bd/ip/ecg_bd_blk_mem_gen_0_0/sim/ecg_bd_blk_mem_gen_0_0.v" \
"../../../bd/ecg_bd/ip/ecg_bd_blk_mem_gen_1_0/sim/ecg_bd_blk_mem_gen_1_0.v" \
"../../../bd/ecg_bd/ip/ecg_bd_ads1292_spi_0_0/sim/ecg_bd_ads1292_spi_0_0.v" \
"../../../bd/ecg_bd/ip/ecg_bd_xlconstant_0_0/sim/ecg_bd_xlconstant_0_0.v" \
"../../../bd/ecg_bd/sim/ecg_bd.v" \

vlog -work xil_defaultlib \
"glbl.v"

